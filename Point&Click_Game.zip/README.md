Point&Click_Game
